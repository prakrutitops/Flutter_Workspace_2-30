//@dart=2.9
import 'package:flutter/material.dart';
import '../../text_column.dart';

class EducationTextColumn extends StatelessWidget {
  const EducationTextColumn();

  @override
  Widget build(BuildContext context) {
    return const TextColumn(
      title: 'CUSTOM GREETING CARDS',
      text: 'E-wishes provide to create owen custom greeting cards.',
    );
  }
}