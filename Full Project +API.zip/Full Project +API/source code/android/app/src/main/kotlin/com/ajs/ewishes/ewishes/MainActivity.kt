package com.ajs.ewishes.ewishes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
