//@dart=2.9
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:amishaproject/screens/user/forgot_password/widgets/header.dart';
import 'package:amishaproject/screens/user/login/login.dart';
import 'package:amishaproject/screens/user/login/widgets/custom_clippers/index.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../constants.dart';
import 'package:http/http.dart' as http;

class ForgotPassword extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return ForgotPasswordPage();
  }
}

class ForgotPasswordPage extends State<ForgotPassword> {
  ForgotPasswordPage();

  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  var newpassword = TextEditingController();
  var confirmnewpassword = TextEditingController();
  var mobilenumber = TextEditingController();
  var otp = TextEditingController();

  bool _isObscurePassword = true;
  bool _isObscureConfirmPassword = true;

  FirebaseAuth auth = FirebaseAuth.instance;
  String verificationIDReceived = "";
  bool otpCodeVisible = true;
  var countryCode="+91";

  void verifyMobileNumber(){
    auth.verifyPhoneNumber(phoneNumber: "$countryCode "+mobilenumber.text,
      verificationCompleted: (PhoneAuthCredential credential) async {
        Fluttertoast.showToast(msg: "Please Wait Few Seconds",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
        await auth.signInWithCredential(credential).then((value){
          updateData();
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => Login()));
        });
      },
      verificationFailed: (FirebaseAuthException exception){
        Fluttertoast.showToast(msg: "Verification Is Failed Please Try Again Later",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
      },
      codeSent: (String verificationID, int resendToken){
        verificationIDReceived = verificationID;
        otpCodeVisible = false;
        setState(() {});
      },
      codeAutoRetrievalTimeout: (String verificationID){},
    );
  }

  void _codeAutoRetrievalTimeout() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: kWhite,
          title: Row(children: [Icon(Icons.error, color: kBrown,),Text("\tServer Error", style: TextStyle(color: kBrown),)],),
          content: Text('Please restart your application.',style: TextStyle(color: kBrown ,fontStyle: FontStyle.italic)),
          actions: <Widget>[
            FlatButton(
              onPressed: () {
                exit(0);
              },
              child: Text("Exit",style: TextStyle(color: kBrown)),
            ),
          ],
        );
      },
    );
  }

  void verifyCode() async {
    Fluttertoast.showToast(msg: "Please Wait Few Seconds",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
    PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: verificationIDReceived, smsCode: otp.text);
    await auth.signInWithCredential(credential).then((value){
      updateData();
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => Login()));
    });
  }

  void updateData(){
    var url = "https://amisha1299.000webhostapp.com/Ewishes/ForgotPassword/forgotpassword_update.php";
    http.post(url,body: {
      'password': newpassword.text,
      'confirm_password': confirmnewpassword.text,
      'mobile_no': mobilenumber.text,
    });
    Fluttertoast.showToast(msg: "Password Update Successfully",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Login()));
  }

  Future viewCheckData() async {
    var url = "https://amisha1299.000webhostapp.com/Ewishes/ForgotPassword/forgotpassword_view.php";
    var response = await http.post(Uri.parse(url), body: {
      "mobile_no": mobilenumber.text,
    });

    var data = json.decode(response.body);

    if(data!=0) {
      verifyMobileNumber();
    }
    else{
      final snackBar = SnackBar(
        content: Text('Something Is Wrong...',
          style: TextStyle(
            color: kLightGold,
          ),
        ),
        duration: Duration(seconds: 5),
        backgroundColor: kDarkBrown,
      );
      scaffoldKey.currentState.showSnackBar(snackBar);
    }
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top;
    final space = height > 650 ? kSpaceM : kSpaceS;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        key: scaffoldKey,
        resizeToAvoidBottomInset: false,
        backgroundColor: kLightGold,
        body: Stack(
          children: [
            ClipPath(
              clipper: const GoldTopClipper(),
              child: Container(color: kGold),
            ),
            ClipPath(
              clipper: const BrownTopClipper(),
              child: Container(color: kBrown),
            ),
            ClipPath(
              clipper: const LightGoldTopClipper(),
              child: Container(color: kLightGold),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: kPaddingL),

                child: Column(
                  children: [
                    Header(),
                    //Spacer(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: kPaddingL),

                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: kSpaceL * 5),
                          Text('To reset your password, enter following details.',
                            style: Theme.of(context).textTheme.subtitle2.copyWith(color: kDarkBrown.withOpacity(0.7)),
                          ),

                          SizedBox(height: space-5),

                          TextField(
                            controller: newpassword,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(kPaddingS+5),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              hintText: 'New Password',
                              hintStyle: TextStyle(
                                color: kBlack.withOpacity(0.5),
                                fontWeight: FontWeight.w500,
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(_isObscurePassword ? Icons.visibility_off : Icons.visibility),
                                onPressed: (){
                                  setState(() {
                                    _isObscurePassword = !_isObscurePassword;
                                  });
                                },
                              ),
                              prefixIcon: Icon(
                                Icons.lock,
                                color: kBlack.withOpacity(0.5),
                              ),
                            ),
                            obscureText: _isObscurePassword,
                          ),

                          SizedBox(height: space-7),

                          TextField(
                            controller: confirmnewpassword,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(kPaddingS+5),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              hintText: 'Confirm New Password',
                              hintStyle: TextStyle(
                                color: kBlack.withOpacity(0.5),
                                fontWeight: FontWeight.w500,
                              ),
                              suffixIcon: IconButton(
                                icon: Icon(_isObscureConfirmPassword ? Icons.visibility_off : Icons.visibility),
                                onPressed: (){
                                  setState(() {
                                    _isObscureConfirmPassword = !_isObscureConfirmPassword;
                                  });
                                },
                              ),
                              prefixIcon: Icon(
                                Icons.lock,
                                color: kBlack.withOpacity(0.5),
                              ),
                            ),
                            obscureText: _isObscureConfirmPassword,
                          ),

                          SizedBox(height: space-7),

                          TextField(
                            controller: mobilenumber,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(kPaddingS+5),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              hintText: 'Mobile Number',
                              hintStyle: TextStyle(
                                color: kBlack.withOpacity(0.5),
                                fontWeight: FontWeight.w500,
                              ),
                              prefixIcon: Icon(
                                Icons.phone,
                                color: kBlack.withOpacity(0.5),
                              ),
                            ),
                          ),

                          SizedBox(height: space-7),

                          TextField(
                            controller: otp,
                            autofocus: true,
                            readOnly: otpCodeVisible,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(kPaddingS+5),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.black.withOpacity(0.12)),
                              ),
                              hintText: 'OTP',
                              hintStyle: TextStyle(
                                color: kBlack.withOpacity(0.5),
                                fontWeight: FontWeight.w500,
                              ),
                              prefixIcon: Icon(
                                Icons.code,
                                color: kBlack.withOpacity(0.5),
                              ),
                            ),
                          ),

                          SizedBox(height: space-5),

                          ConstrainedBox(
                            constraints: const BoxConstraints(
                              minWidth: double.infinity,
                            ),
                            child: TextButton(
                              style: TextButton.styleFrom(
                                backgroundColor: kDarkBrown,
                                padding: const EdgeInsets.all(kPaddingS+5),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4.0),
                                ),
                              ),
                              onPressed: (){
                                String  PasswordPattern = r'^(?=.*?[!@#\$&*~])';
                                RegExp regExp = new RegExp(PasswordPattern);

                                if(!otpCodeVisible){
                                  if(!otp.text.isEmpty) {
                                    if (otp.text.length!=6) {
                                      final snackBar = SnackBar(
                                        content: Text('Invalid OTP',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else{
                                      verifyCode();
                                    }
                                  }
                                  else{
                                    if (otp.text.isEmpty) {
                                      final snackBar = SnackBar(
                                        content: Text('Please Enter OTP',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                  }
                                }
                                else{
                                  if (!newpassword.text.isEmpty && !confirmnewpassword.text.isEmpty && !mobilenumber.text.isEmpty) {
                                    if(!regExp.hasMatch(newpassword.text)){
                                      final snackBar = SnackBar(
                                        content: Text('Must Contain Special Character Either . * @ # \$',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else if(newpassword.text!=confirmnewpassword.text){
                                      final snackBar = SnackBar(
                                        content: Text('Password Does Not Match',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else if(mobilenumber.text.length!=10){
                                      final snackBar = SnackBar(
                                        content: Text('Invalid Mobile Number',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else{
                                      Timer(Duration(seconds: 60), ()=>_codeAutoRetrievalTimeout());
                                      viewCheckData();
                                    }
                                  }
                                  else{
                                    if(newpassword.text.isEmpty){
                                      final snackBar = SnackBar(
                                        content: Text('Please Enter Password',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else if(confirmnewpassword.text.isEmpty){
                                      final snackBar = SnackBar(
                                        content: Text('Please Enter Confirm Password',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                    else if(mobilenumber.text.isEmpty){
                                      final snackBar = SnackBar(
                                        content: Text('Please Enter Mobile Number',
                                          style: TextStyle(
                                            color: kLightGold,
                                          ),
                                        ),
                                        duration: Duration(seconds: 2),
                                        backgroundColor: kDarkBrown,
                                      );
                                      scaffoldKey.currentState.showSnackBar(snackBar);
                                    }
                                  }
                                }
                              },
                              child: Text("Update a E-wishes Password",
                                style: Theme.of(context).textTheme.subtitle1.copyWith(color: kGold, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),

                          SizedBox(height: space-7),

                          ConstrainedBox(
                            constraints: const BoxConstraints(
                              minWidth: double.infinity,
                            ),
                            child: TextButton(
                              style: TextButton.styleFrom(
                                backgroundColor: kGold,
                                padding: const EdgeInsets.all(kPaddingS+5),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4.0),
                                ),
                              ),
                              onPressed: (){
                                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Login()));
                              },
                              child: Text("Back to E-wishes? Login",
                                style: Theme.of(context).textTheme.subtitle1.copyWith(color: kDarkBrown, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                          SizedBox(height: space-5),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}