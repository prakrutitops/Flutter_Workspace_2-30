//@dart=2.9
import 'dart:math';
import 'package:flutter/material.dart';
import '../../../constants.dart';

class Header extends StatelessWidget {
  const Header();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kPaddingM-5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
            children:[
              Column(
                  children:[
                    Image(
                      image: AssetImage('images/logo.png'),
                      height: 70,
                      width: 70,
                    ),
                  ]
              ),

              Padding(padding: EdgeInsets.symmetric(horizontal: 10)),

              Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:[
                    Image(
                      image: AssetImage('images/name.png'),
                      height: 60,
                      width: 180,
                    ),

                    Image(
                      image: AssetImage('images/tagLine.png'),
                      height: 30,
                      width: 200,
                    ),
                  ]
              ),
            ]
        ),



          //Transform(
            //angle: -pi / 4,
         /* Padding(padding: EdgeInsets.all(2),
            child: Image(
              image: AssetImage('images/logo.png'),
              height:  80,
            ),),
         // ),


          const SizedBox(height: kSpaceM),
          Text('Welcome to E-wishes',
            style: Theme.of(context).textTheme.headline5.copyWith(color: kBlack, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: kSpaceS),
          Text('To reset your password, enter following details.',
            style: Theme.of(context).textTheme.subtitle1.copyWith(color: kBrown.withOpacity(0.5)),
          ),*/
        ],
      ),
    );
  }
}