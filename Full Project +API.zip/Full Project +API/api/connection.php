<?php
    define('HOST','localhost');
    define('USER','id18343629_tops');
    define('DB','id18343629_ewishes');
    define('PASS','Tops@12345678');
    
    $con=mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');
?>